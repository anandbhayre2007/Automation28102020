package conditionalStatement;

public class ConditionalStatement2 {

	public static void main(String[] args) {
		

	//Test case 1	
		//Launch browser - failed
		//Navigate -
		//Verify Google logo -
		
		
	//Test case 2:
		//Verify Gmail link is present -failed
		//Verify Images link is present
		//Verify User icon is present
		
		
		boolean step1=false;
		boolean step2= false;
		boolean step3= false;
		
		//Step 1
		if(step1)
		{
			System.out.println("Test step1 is passed");
			
		}else {
			System.out.println("Test step1 is failed");
		}
		
		//Step 2
		if(step2)
		{
			System.out.println("Test step2 is passed");
		}else {
			System.out.println("Test step2 is failed");
		}
		
		//Step 3
		if(step3)
		{
			System.out.println("Test step3 is passed");
			
		}else {
			System.out.println("Test step3 is failed");
		}

	}

}
