package conditionalStatement;

public class ConditionalStatement1 {

	public static void main(String[] args) {
		
		//Conditional Statements
		
		int a=10;
		int b=20;
		
		//Relational Operators
		//>, <, >=, <=, !=, ==
		
		System.out.println(a>b);
		
		
		if(a>b)
		{
			System.out.println("a is greater than b");
		}else if(a==b){
			System.out.println("a is equal to b");
		}else {
			System.out.println("b is greater than a");
		}
		
		//Launch browser - failed
		//Navigate -
		//Verify Google logo -
		
		

	}

}
