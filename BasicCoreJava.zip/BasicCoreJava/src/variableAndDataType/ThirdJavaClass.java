package variableAndDataType;

public class ThirdJavaClass {

	public static void main(String[] args) {
		int a=21;
		int b=20;
		
		//Mathematical operator
		//+, -, *, /, %
		
		/*
		System.out.println(a+b);
		System.out.println(b-a);
		System.out.println(a*b);
		System.out.println(a/b);
		*/
		
		//% -mode
		
		System.out.println(b%a);

	}

}
