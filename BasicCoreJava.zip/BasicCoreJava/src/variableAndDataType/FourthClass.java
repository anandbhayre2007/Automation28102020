package variableAndDataType;

public class FourthClass {

	public static void main(String[] args) {
		
		//System.out.println("anand");
		
		int a=10;		
		int b=20;		
		String name="anand";
		String name2="Danish";
		
		System.out.println(a+b);
		
		System.out.println(name+name2);
		
		//Addition
		//Concetination
		
		System.out.println(a+b+name);
		
		System.out.println(name+a);
		
		System.out.println((name)+(a+b));
		
		//anand30
	}
	
}
