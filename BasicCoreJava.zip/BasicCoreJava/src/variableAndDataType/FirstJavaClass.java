package variableAndDataType;

public class FirstJavaClass {

	public static void main(String[] args) {
		int a=10;
		
		System.out.println(a);

	}

}
