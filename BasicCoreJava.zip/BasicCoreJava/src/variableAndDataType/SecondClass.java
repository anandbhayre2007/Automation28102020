package variableAndDataType;

public class SecondClass {

		
	public static void main(String[] args) {
		
		//Local Variables
		
		//Age = 32
		//Name =Anand
		//Marital Status = true
		//Height = 5.8
		//Gender = F
		
		int age=32;
		String name="anand";
		boolean maritalStatus=true;
		double  height=5.8;
		char gender='F';
		
		//byte, short, int, long -->>difference datatype (tutorials points, and javatpoint)
		
		//float, double = -->>difference datatype (tutorials points, and javatpoint)
		
		
		//Primitive Data Type
		//1. byte
		//2. short
		//3. int
		//4.  long
		//5. boolean
		//6.  double
		//7.  float
		//8.  char
		
		//Non primitive
		//class, interface, array etc.
		
		
	}

}
